<form method="POST" action="index.php?act=login">
        <table>
            <tr>
                <td colspan="2"><span style="font-weight:bold;font-size:20px;">Admin Login</span></td>
            </tr>
            <tr>
                <td>Username</td>
                <td><input type="text" name="username" size="20"></td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input type="password" name="password" size="20"></td>
            </tr>
            <tr>
                <td colspan="2" align="right"> <input name="btn_submit" type="submit" value="Login"></td>
            </tr>
        </table>
    </form>